import * as main from "./main.js";

window.onload = () => {
	// load fonts, sounds, whatever ...
	main.init();
};